import os
import openai
import numpy as np
from PyPDF2 import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Get your OpenAI API key from environment variables
openai.api_key = os.getenv('OPENAI_API_KEY')

# Load documents from the "data" folder (PDF files)
def load_documents(folder_path):
    documents = {}
    for filename in os.listdir(folder_path):
        if filename.endswith('.pdf'):
            with open(os.path.join(folder_path, filename), 'rb') as file:
                reader = PdfReader(file)
                text = ""
                for page in range(len(reader.pages)):
                    text += reader.pages[page].extract_text()
                documents[filename] = text
    return documents

# Preprocess and vectorize documents using TF-IDF
def preprocess_documents(documents):
    vectorizer = TfidfVectorizer(stop_words='english')
    doc_names = list(documents.keys())
    doc_texts = list(documents.values())
    tfidf_matrix = vectorizer.fit_transform(doc_texts)
    return vectorizer, tfidf_matrix, doc_names

# Retrieve the top N most relevant documents
def retrieve_documents(query, vectorizer, tfidf_matrix, doc_names, top_n=3):
    query_vector = vectorizer.transform([query])
    similarities = cosine_similarity(query_vector, tfidf_matrix).flatten()
    relevant_indices = similarities.argsort()[-top_n:][::-1]
    relevant_docs = [doc_names[i] for i in relevant_indices]
    return relevant_docs

# Generate a response using the GPT-3.5-turbo model
def generate_response(query, relevant_docs, documents):
    context = "\n\n".join([f"{doc}: {documents[doc]}" for doc in relevant_docs])
    prompt = f"Based on the following documents:\n\n{context}\n\nAnswer the following query:\n{query}"
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": "You are a helpful assistant."},
                  {"role": "user", "content": prompt}]
    )
    return response.choices[0].message['content']

# Main function to handle the query and retrieve augmented response
def rag_query(query, folder_path="data"):
    documents = load_documents(folder_path)
    vectorizer, tfidf_matrix, doc_names = preprocess_documents(documents)
    relevant_docs = retrieve_documents(query, vectorizer, tfidf_matrix, doc_names)
    response = generate_response(query, relevant_docs, documents)
    return response

# Example usage
query = "What are the main points discussed in the documents about climate change?"
response = rag_query(query)
print(response)
