import os
import streamlit as st
from streamlit_chat import message
from rag import Chat_RAG
import warnings
import time

warnings.filterwarnings("ignore")

st.set_page_config(page_title="NBA - NAAC Chatbot")

# Initialize session state variables
if "messages" not in st.session_state:
    st.session_state["messages"] = []
if "ingestion_complete" not in st.session_state:
    st.session_state["ingestion_complete"] = False
if "assistant" not in st.session_state:
    openai_api_key = "sk-proj-hCCMo1OkCxZYvErczzogT3BlbkFJgripu3EcpdEkJUPWZApE" #os.getenv("OPENAI_API_KEY")  # Ensure this environment variable is set
    st.session_state["assistant"] = Chat_RAG(openai_api_key=openai_api_key)

def ingest_files():
    st.session_state["assistant"].clear()
    st.session_state["messages"] = []
    st.session_state["user_input"] = ""

    data_folder = "data"
    for filename in os.listdir(data_folder):
        if filename.endswith('.pdf'):
            file_path = os.path.join(data_folder, filename)
            with st.spinner(f"Ingesting {filename}"):
                st.session_state["assistant"].ingest(file_path)

    st.session_state["ingestion_complete"] = True

def display_messages():
    st.subheader("Chat")
    for i, (msg, is_user) in enumerate(st.session_state["messages"]):
        message(msg, is_user=is_user, key=str(i))
    st.session_state["thinking_spinner"] = st.empty()

def process_input():
    if st.session_state["user_input"] and len(st.session_state["user_input"].strip()) > 0:
        user_text = st.session_state["user_input"].strip()
        with st.session_state["thinking_spinner"], st.spinner(f"Thinking"):
            agent_text = st.session_state["assistant"].ask(user_text)

        st.session_state["messages"].append((user_text, True))
        st.session_state["messages"].append((agent_text, False))

def page():
    if not st.session_state["ingestion_complete"]:
        st.warning("Documents are still being ingested. Please try again in a few moments.")
        return

    st.header("NBA NAAC - Chatbot")

    display_messages()
    st.text_input("Message", key="user_input", on_change=process_input)

# Start ingestion when the script is run
if not st.session_state["ingestion_complete"]:
    ingest_files()

if __name__ == "__main__":
    page()
